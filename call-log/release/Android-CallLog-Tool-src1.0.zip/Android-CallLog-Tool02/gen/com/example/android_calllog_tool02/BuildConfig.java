/** Automatically generated file. DO NOT MODIFY */
package com.example.android_calllog_tool02;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}